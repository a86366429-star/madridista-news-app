// Vercel serverless function: retrieves Google News RSS and returns a small list of headlines.
// This is a starter implementation. Respect source terms and do not republish full articles.
const CATEGORY_QUERIES = {
  latest: 'Real Madrid football',
  transfers: 'Real Madrid transfer OR signing OR mercato',
  matches: 'Real Madrid match OR Champions League OR La Liga',
  injuries: 'Real Madrid injury OR injured OR fitness',
  spanish: 'Real Madrid',
};

function decodeEntities(s = "") {
  return s
    .replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}
function stripCDATA(s = "") { return s.replace(/^<!\[CDATA\[/, "").replace(/\]\]>$/, ""); }
function tag(block, name) {
  const match = block.match(new RegExp("<" + name + "(?:\\s[^>]*)?>([\\s\\S]*?)</" + name + ">", "i"));
  return match ? decodeEntities(stripCDATA(match[1].trim().replace(/<[^>]*>/g, ""))) : "";
}
function safeLink(s = "") {
  try { const u = new URL(s); return ["http:", "https:"].includes(u.protocol) ? u.toString() : ""; }
  catch { return ""; }
}
function parseRSS(xml, categoryLabel) {
  const blocks = xml.match(/<item(?:\s[^>]*)?>[\s\S]*?<\/item>/gi) || [];
  return blocks.map(block => {
    const title = tag(block, "title");
    const link = safeLink(tag(block, "link"));
    const pubDate = tag(block, "pubDate");
    const source = tag(block, "source") || "Google News";
    return { title, link, pubDate, source, categoryLabel };
  }).filter(x => x.title && x.link);
}
module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=600");
  res.setHeader("Access-Control-Allow-Origin", "*");
  const category = String(req.query.category || "latest").toLowerCase();
  const q = String(req.query.q || "").trim().slice(0, 100);
  const baseQuery = q || CATEGORY_QUERIES[category] || CATEGORY_QUERIES.latest;
  const isSpanish = category === "spanish" && !q;
  const feeds = [
    { url: `https://news.google.com/rss/search?q=${encodeURIComponent(baseQuery)}&hl=ar&gl=IQ&ceid=IQ:ar`, label: isSpanish ? "صحافة إسبانيا" : "أخبار" },
    { url: `https://news.google.com/rss/search?q=${encodeURIComponent(baseQuery)}&hl=es&gl=ES&ceid=ES:es`, label: isSpanish ? "صحافة إسبانيا" : "أخبار دولية" }
  ];
  try {
    const responses = await Promise.all(feeds.map(f => fetch(f.url, { headers: { "User-Agent": "MadridistaFanNews/1.0" } })));
    const xmls = await Promise.all(responses.map(async r => {
      if (!r.ok) throw new Error("News feed unavailable");
      return r.text();
    }));
    const labelMap = { latest: "آخر الأخبار", transfers: "انتقالات", matches: "مباريات", injuries: "إصابات", spanish: "صحافة إسبانيا" };
    let items = xmls.flatMap((xml, i) => parseRSS(xml, q ? "بحث" : (i === 1 && isSpanish ? "صحافة إسبانيا" : (labelMap[category] || "أخبار"))));
    const seen = new Set();
    items = items.filter(item => {
      const key = item.title.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0, 30);
    res.status(200).json({ items, fetchedAt: new Date().toISOString() });
  } catch (err) {
    res.status(502).json({ error: "مصدر الأخبار غير متاح مؤقتاً. حاول مرة ثانية لاحقاً." });
  }
};
